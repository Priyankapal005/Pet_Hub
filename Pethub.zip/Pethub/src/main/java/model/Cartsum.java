/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author BSIL
 */
public class Cartsum {
 String total;
 
   public String gettotal() {
       return total;
    }
   
      public void settotal(String total) {
        this.total= total;
    }
}
